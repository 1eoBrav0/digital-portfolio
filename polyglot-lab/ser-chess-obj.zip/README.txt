Ser Chess Atelier
Units: metres. Board approx. 0.46 m wide.
Keep OBJ and MTL in the same folder. Geometry is editable.
GLB preserves PBR materials more accurately; OBJ/MTL uses legacy shading.
Original digital concept, not a manufacturing model. MIT license.
