module ser/radar

go 1.24
