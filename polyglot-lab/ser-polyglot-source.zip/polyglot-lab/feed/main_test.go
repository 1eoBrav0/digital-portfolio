package main

import (
	"strings"
	"testing"
)

func TestCanonical(t *testing.T) {
	u, e := canonical("https://EXAMPLE.invalid/a?utm_source=mail&v=2#top")
	if e != nil || u != "https://example.invalid/a?v=2" {
		t.Fatal(u, e)
	}
	for _, s := range []string{"javascript:alert(1)", "file:///x", "https://u:p@host/a"} {
		if _, e := canonical(s); e == nil {
			t.Fatal(s)
		}
	}
}
func TestRSSAtomDedup(t *testing.T) {
	r := merge(map[string][]byte{"a": []byte(`<rss><channel><item><title>A</title><link>https://example.invalid/a?utm_source=x</link></item></channel></rss>`), "b": []byte(`<feed xmlns="http://www.w3.org/2005/Atom"><entry><title>B</title><link href="https://example.invalid/a"/></entry></feed>`)}, "")
	if r.Read != 2 || r.Duplicates != 1 || len(r.Items) != 1 {
		t.Fatal(r)
	}
}
func TestMalformedIsolated(t *testing.T) {
	r := merge(map[string][]byte{"bad": []byte(`<rss>`), "good": []byte(`<rss><channel><item><title>A</title><link>https://example.invalid/a</link></item></channel></rss>`)}, "")
	if len(r.Errors) != 1 || len(r.Items) != 1 {
		t.Fatal(r)
	}
}
func TestNoEntity(t *testing.T) {
	if _, e := parse([]byte(`<!DOCTYPE rss><rss/>`), "x"); e == nil {
		t.Fatal("DTD")
	}
}
func TestSize(t *testing.T) {
	if _, e := parse([]byte(strings.Repeat("x", 2*1024*1024+1)), "x"); e == nil {
		t.Fatal("limit")
	}
}
func TestFilter(t *testing.T) {
	r := merge(map[string][]byte{"a": []byte(`<rss><channel><item><title>Database update</title><link>https://example.invalid/a</link></item><item><title>Other</title><link>https://example.invalid/b</link></item></channel></rss>`)}, "DATABASE")
	if len(r.Items) != 1 || r.Filtered != 1 {
		t.Fatal(r)
	}
}
func TestDatesAndCSV(t *testing.T) {
	if date("2026-11-25T03:00:00+03:00") != "2026-11-25T00:00:00Z" {
		t.Fatal("timezone")
	}
	if date("bad") != "" {
		t.Fatal("bad date")
	}
	if csvCell("=1+1") != "'=1+1" {
		t.Fatal("CSV")
	}
	if csvCell("") != "" {
		t.Fatal("empty")
	}
}
