<?php
require __DIR__.'/domain.php';$count=0;
function check(bool $ok,string $label):void{global $count;if(!$ok)throw new Exception($label);$count++;echo "PASS $label\n";}
function rejected(callable $fn):bool{try{$fn();return false;}catch(Throwable $e){return true;}}
$db=connect(':memory:');check(parseOrder("sku;qty\nSK-101;2\nSK-101;3")===['SK-101'=>5],'duplicate rows consolidated');
check(quote($db,['SK-101'=>2])['total']===122400,'integer kopecks and discount');
foreach(["SK-101;-2","SK-101;1.5","SK-999;1","SK-101;9999",''] as $v)check(rejected(fn()=>quote($db,parseOrder($v))),'invalid input rejected');
$a=place($db,'SK-101;2','test-key-123');$b=place($db,'SK-101;2','test-key-123');check($a['id']===$b['id']&&$b['replayed'],'replay does not create another order');check((int)$db->query("SELECT stock FROM products WHERE sku='SK-101'")->fetchColumn()===118,'stock decremented once');check(rejected(fn()=>place($db,'SK-101;3','test-key-123')),'conflicting replay rejected');
check(rejected(fn()=>place($db,"SK-102;1\nSK-106;999",'test-key-456')),'insufficient stock rejects whole order');check((int)$db->query("SELECT stock FROM products WHERE sku='SK-102'")->fetchColumn()===340,'failed order preserves stock');echo "$count checks passed\n";
