import test from 'node:test';import assert from 'node:assert/strict';import {CRM} from './domain.js';
const valid={company:'Тест',title:'Импорт',owner:'Анна',amount:12000,due:'2026-11-25'};
test('valid deal persists and audit is atomic',()=>{const c=new CRM(':memory:');const id=c.add(valid);assert.equal(c.list()[0].amount,12000);c.move(id,'В работе',1);assert.equal(c.list()[0].version,2);assert.equal(c.db.prepare('SELECT count(*) n FROM events').get()?.n,2);c.close();});
test('stale update cannot overwrite current state',()=>{const c=new CRM(':memory:');const id=c.add(valid);c.move(id,'В работе',1);assert.throws(()=>c.move(id,'Завершена',1));assert.equal(c.list()[0].stage,'В работе');c.close();});
test('invalid amount/date/empty name never saved',()=>{const c=new CRM(':memory:');for(const patch of [{amount:-1},{amount:1.2},{due:'2026-02-30'},{company:''}])assert.throws(()=>c.add({...valid,...patch}));assert.equal(c.list().length,0);c.close();});
test('unknown stage rolls back, SQL payload stored as text',()=>{const c=new CRM(':memory:');const id=c.add({...valid,company:"x'); DROP TABLE deals;--"});assert.throws(()=>c.move(id,'fake',1));assert.equal(c.list().length,1);c.close();});
