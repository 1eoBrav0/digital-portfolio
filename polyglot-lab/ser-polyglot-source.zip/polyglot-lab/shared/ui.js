export const $=s=>document.querySelector(s);
export const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const rub=v=>new Intl.NumberFormat('ru-RU',{style:'currency',currency:'RUB',maximumFractionDigits:0}).format(v);
export const shell=(product,content)=>{document.body.innerHTML=`<header><a href="/" aria-label="Все проекты"><img src="/shared/ser-black.png" alt="Ser"></a><div class="product">${product}</div><div class="demo">Демонстрационные данные</div></header><main>${content}<footer class="site-footer"><span>Ser · ${product} · самостоятельный демонстрационный проект</span><a href="/">Все проекты</a></footer></main>`;};
export function notice(message,error=false){const n=$('#notice');n.textContent=message;n.className='notice'+(error?' error':'');}
export async function api(url,body,method='POST'){const r=await fetch(url,body===undefined?{}:{method,headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const data=await r.json();if(!r.ok)throw Error(data.error||'Ошибка запроса');return data;}
export function download(name,text,type='text/csv;charset=utf-8'){const url=URL.createObjectURL(new Blob([text],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);}
export const stat=(name,value)=>`<div class="stat"><span>${name}</span><b>${value}</b></div>`;

export const localTime=v=>new Intl.DateTimeFormat('ru-RU',{timeZone:'Asia/Yakutsk',dateStyle:'short',timeStyle:'short'}).format(new Date(v.replace(' ','T')+'Z'));
