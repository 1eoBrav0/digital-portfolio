import {writeFileSync} from 'node:fs';
import {deflateRawSync} from 'node:zlib';
import {fileURLToPath} from 'node:url';
import {GLTFExporter} from 'three/addons/exporters/GLTFExporter.js';
import {OBJExporter} from 'three/addons/exporters/OBJExporter.js';
import {createChess} from './model.mjs';

// GLTFExporter expects the standard browser FileReader; Node supplies Blob.
globalThis.FileReader=class {
  readAsArrayBuffer(blob){blob.arrayBuffer().then(result=>{this.result=result;this.onloadend?.();}).catch(error=>this.onerror?.(error));}
  readAsDataURL(blob){blob.arrayBuffer().then(result=>{this.result=`data:${blob.type};base64,${Buffer.from(result).toString('base64')}`;this.onloadend?.();}).catch(error=>this.onerror?.(error));}
};
const dir=fileURLToPath(new URL('.',import.meta.url));
const {root,materials}=createChess();root.scale.setScalar(.05);root.userData.exportUnit='metre';root.updateMatrixWorld(true);
for(const m of Object.values(materials))m.name=m.name.replaceAll(' ','_');
const data=await new GLTFExporter().parseAsync(root,{binary:true,onlyVisible:true});
writeFileSync(dir+'ser-chess.glb',Buffer.from(data));
const obj='# Ser Chess Atelier. Units: metres. Original parametric geometry.\nmtllib ser-chess.mtl\n'+new OBJExporter().parse(root);
const mtl=Object.values(materials).map(m=>`newmtl ${m.name}\nKa 0.05 0.05 0.05\nKd ${m.color.r.toFixed(5)} ${m.color.g.toFixed(5)} ${m.color.b.toFixed(5)}\nKs ${m.metalness.toFixed(3)} ${m.metalness.toFixed(3)} ${m.metalness.toFixed(3)}\nNs ${Math.round((1-m.roughness)*150)}\nd 1\nillum 2\n`).join('\n');
// Minimal portable ZIP writer: DEFLATE, CRC32, UTF-8 entry names.
const table=Array.from({length:256},(_,n)=>{for(let k=0;k<8;k++)n=(n&1)?0xedb88320^(n>>>1):n>>>1;return n>>>0;});
const crc32=b=>{let n=0xffffffff;for(const x of b)n=table[(n^x)&255]^(n>>>8);return (n^0xffffffff)>>>0;};
function zip(entries){let offset=0;const chunks=[],central=[];for(const [name,text] of entries){const raw=Buffer.from(text),compressed=deflateRawSync(raw,{level:9}),filename=Buffer.from(name),crc=crc32(raw);const local=Buffer.alloc(30);local.writeUInt32LE(0x04034b50);local.writeUInt16LE(20,4);local.writeUInt16LE(0x800,6);local.writeUInt16LE(8,8);local.writeUInt32LE(crc,14);local.writeUInt32LE(compressed.length,18);local.writeUInt32LE(raw.length,22);local.writeUInt16LE(filename.length,26);chunks.push(local,filename,compressed);const entry=Buffer.alloc(46);entry.writeUInt32LE(0x02014b50);entry.writeUInt16LE(20,4);entry.writeUInt16LE(20,6);entry.writeUInt16LE(0x800,8);entry.writeUInt16LE(8,10);entry.writeUInt32LE(crc,16);entry.writeUInt32LE(compressed.length,20);entry.writeUInt32LE(raw.length,24);entry.writeUInt16LE(filename.length,28);entry.writeUInt32LE(offset,42);central.push(entry,filename);offset+=local.length+filename.length+compressed.length;}const directory=Buffer.concat(central),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50);end.writeUInt16LE(entries.length,8);end.writeUInt16LE(entries.length,10);end.writeUInt32LE(directory.length,12);end.writeUInt32LE(offset,16);return Buffer.concat([...chunks,directory,end]);}
writeFileSync(dir+'ser-chess-obj.zip',zip([['ser-chess.obj',obj],['ser-chess.mtl',mtl],['README.txt','Ser Chess Atelier\nUnits: metres. Board approx. 0.46 m wide.\nKeep OBJ and MTL in the same folder. Geometry is editable.\nGLB preserves PBR materials more accurately; OBJ/MTL uses legacy shading.\nOriginal digital concept, not a manufacturing model. MIT license.\n']]));
console.log(JSON.stringify({glbBytes:data.byteLength,objBytes:Buffer.byteLength(obj),materials:Object.keys(materials).length}));
