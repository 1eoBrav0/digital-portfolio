import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {createChess} from './model.mjs';
const stage=document.querySelector('#stage');
let renderer;
try{renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,preserveDrawingBuffer:true});}
catch(error){document.querySelector('#loading').textContent='WebGL недоступен. Модель можно скачать в GLB или OBJ.';throw error;}
renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.08;stage.appendChild(renderer.domElement);
const scene=new THREE.Scene();scene.background=new THREE.Color('#151b1c');scene.fog=new THREE.Fog('#151b1c',26,48);
const camera=new THREE.PerspectiveCamera(35,1,.05,80);camera.position.set(10,9,12);
const controls=new OrbitControls(camera,renderer.domElement);controls.target.set(0,.3,0);controls.enableDamping=true;controls.dampingFactor=.075;controls.minDistance=3;controls.maxDistance=27;controls.maxPolarAngle=Math.PI*.485;controls.autoRotateSpeed=.6;
scene.add(new THREE.HemisphereLight(0xf5ead5,0x526c73,2.2));
// A small studio environment supplies broad reflections without external HDR files.
const studio=new THREE.Scene();studio.background=new THREE.Color(0x555b5b);
for(const [position,size,color,intensity] of [[[-5,6,3],[5,7],0xffeed5,3],[[6,4,-5],[3,6],0xd7ecff,2],[[0,9,0],[8,5],0xffffff,2]]){
  const panel=new THREE.Mesh(new THREE.PlaneGeometry(...size),new THREE.MeshBasicMaterial({color:new THREE.Color(color).multiplyScalar(intensity),side:THREE.DoubleSide}));panel.position.set(...position);panel.lookAt(0,0,0);studio.add(panel);
}
const pmrem=new THREE.PMREMGenerator(renderer);scene.environment=pmrem.fromScene(studio,.08,.1,30).texture;scene.environmentIntensity=.42;pmrem.dispose();
function areaLike(color,intensity,position){const light=new THREE.DirectionalLight(color,intensity);light.position.set(...position);scene.add(light);return light;}
const key=areaLike(0xffebcc,2.8,[-5,11,7]);key.castShadow=true;key.shadow.mapSize.set(2048,2048);key.shadow.camera.left=-8;key.shadow.camera.right=8;key.shadow.camera.top=8;key.shadow.camera.bottom=-8;key.shadow.camera.near=.1;key.shadow.camera.far=35;key.shadow.bias=-.00015;key.shadow.normalBias=.02;key.shadow.radius=3;
areaLike(0xb4d9ee,2.3,[6,7,-8]);areaLike(0xffffff,.8,[8,3,4]);
const floor=new THREE.Mesh(new THREE.PlaneGeometry(200,200),new THREE.MeshStandardMaterial({color:0x151b1c,roughness:.93}));floor.rotation.x=-Math.PI/2;floor.position.y=-.49;floor.receiveShadow=true;scene.add(floor);
const model=createChess();scene.add(model.root);
window.chessModel=model;window.chessScene=scene;
const presets={full:{pos:[10,9,12],target:[0,.3,0]},detail:{pos:[3.1,3.2,7.5],target:[.1,.8,3.0]},top:{pos:[0,18,.01],target:[0,0,0]}};
let animation=null;
function preset(name){const p=presets[name];animation={start:performance.now(),from:camera.position.clone(),to:new THREE.Vector3(...p.pos),targetFrom:controls.target.clone(),targetTo:new THREE.Vector3(...p.target)};document.querySelectorAll('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===name));}
document.querySelectorAll('[data-view]').forEach(b=>b.addEventListener('click',()=>preset(b.dataset.view)));
document.querySelector('#wire').onclick=e=>{const state=e.currentTarget.getAttribute('aria-pressed')!=='true';e.currentTarget.setAttribute('aria-pressed',String(state));Object.values(model.materials).forEach(m=>m.wireframe=state);};
document.querySelector('#explode').onclick=e=>{const state=e.currentTarget.getAttribute('aria-pressed')!=='true';e.currentTarget.setAttribute('aria-pressed',String(state));for(const p of model.pieces){const [x,y,z]=p.userData.home;p.position.set(x*(state?1.25:1),y+(state?1.1:0),z*(state?1.25:1));}document.querySelector('#hint').textContent=state?'Фигуры подняты над доской · Нажмите «Разобрать» ещё раз для сборки':'Перетащите для вращения · Колесо мыши для приближения';};
document.querySelector('#rotate').onclick=e=>{controls.autoRotate=!controls.autoRotate;e.currentTarget.setAttribute('aria-pressed',String(controls.autoRotate));};
const resize=()=>{const w=stage.clientWidth,h=stage.clientHeight;renderer.setSize(w,h);camera.aspect=w/h;camera.fov=Math.max(35,THREE.MathUtils.radToDeg(2*Math.atan(Math.tan(THREE.MathUtils.degToRad(27.5))/camera.aspect)));camera.updateProjectionMatrix();};new ResizeObserver(resize).observe(stage);resize();controls.update();
renderer.setAnimationLoop(()=>{if(animation){const t=Math.min(1,(performance.now()-animation.start)/650),f=t*t*(3-2*t);camera.position.lerpVectors(animation.from,animation.to,f);controls.target.lerpVectors(animation.targetFrom,animation.targetTo,f);if(t===1)animation=null;}controls.update();renderer.render(scene,camera);});
document.querySelector('#loading').remove();document.documentElement.dataset.ready='true';
